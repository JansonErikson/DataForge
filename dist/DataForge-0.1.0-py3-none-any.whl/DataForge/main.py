import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler, StandardScaler

from utils import convert_time_column

class DataFrameAnalyzer:
    def __init__(self, df):
        """
        Constructor of the DataFrameAnalyzer class.
        
        :param df: The DataFrame to be analyzed.
        """
        self.df = convert_time_column(df)  # Convert time column to datetime format
        
    def analyze(self):
        """
        Performs a comprehensive analysis of the DataFrame, including data types,
        number of rows, missing values, outliers, value ranges, and the best
        time window with available values for all columns.
        """
        print("Data types:")
        print(self.df.dtypes)
        print()
        
        print("Number of rows:")
        print(len(self.df))
        print()
        print("Number of rows of each column:")
        print(self.df.count())
        print()
        
        print("First and last value of each column (if datetime):")
        for col in self.df.columns:
            if pd.api.types.is_datetime64_any_dtype(self.df[col]):
                print(f"{col}: {self.df[col].min()} to {self.df[col].max()}")
        print()
        
        print("Missing values per column:")
        print(self.df.isnull().sum())
        print()
        
        print("Outliers per column (values outside 1.5 times the interquartile range):")
        for col in self.df.columns:
            if pd.api.types.is_numeric_dtype(self.df[col]):
                Q1 = self.df[col].quantile(0.25)
                Q3 = self.df[col].quantile(0.75)
                IQR = Q3 - Q1
                lower_bound = Q1 - 1.5 * IQR
                upper_bound = Q3 + 1.5 * IQR
                outliers = self.df[(self.df[col] < lower_bound) | (self.df[col] > upper_bound)]
                print(f"{col}: {len(outliers)} outliers")
        print()
        
        print("Scale of values per column:")
        for col in self.df.columns:
            if pd.api.types.is_numeric_dtype(self.df[col]):
                print(f"{col}: Min={self.df[col].min()}, Max={self.df[col].max()}")
        print()
        
        print("Best time window with available values for all columns:")
        complete_data = self.df.dropna()
        if not complete_data.empty:
            start_date = complete_data.iloc[0]
            end_date = complete_data.iloc[-1]
            print(f"From {start_date.name} ({start_date.iloc[0]}) to {end_date.name} ({end_date.iloc[0]})")
        else:
            print("No complete data found.")
        print()
        

    def fill_missing_values(self, strategy='mean', fill_value=None):
        """
        Fills missing values in the DataFrame based on the specified strategy.
        
        :param strategy: The strategy for filling missing values ('mean', 'median', 'most_frequent', 'constant').
        :param fill_value: The value to fill the missing values with when strategy='constant'.
        :return: The DataFrame with filled missing values.
        """
        if strategy == 'constant' and fill_value is None:
            raise ValueError("fill_value must be provided when strategy is 'constant'.")
        
        if strategy == 'linear':
            self.df.interpolate(method='linear', inplace=True)
        else:
            imputer = SimpleImputer(strategy=strategy, fill_value=fill_value)
            numeric_columns = self.df.select_dtypes(include=['float64', 'int64']).columns
            self.df[numeric_columns] = imputer.fit_transform(self.df[numeric_columns])
        return self.df
    
    def auto_scale_data(self):
        """
        Automatically scales the numeric columns of the DataFrame based on their value ranges.
        MinMaxScaler is used if values greater than 1 are present, otherwise StandardScaler.
        
        :return: The DataFrame with scaled numeric columns.
        """
        numeric_columns = self.df.select_dtypes(include=['float64', 'int64']).columns
        
        for col in numeric_columns:
            if (self.df[col] >= 0).all() and (self.df[col] <= 1).all():
                # All values are between 0 and 1, no scaling needed
                continue
            elif (self.df[col] > 1).any():
                # Some values are greater than 1, use MinMaxScaler
                scaler = MinMaxScaler()
            else:
                # Values are less than 1 and greater than -1, use StandardScaler
                scaler = StandardScaler()
            
            self.df[col] = scaler.fit_transform(self.df[[col]])
        
        return self.df
    
    def preprocess_data(self, fill_strategy='mean', fill_value=None, scale_data=True):
        """
        Performs preprocessing of the DataFrame, including filling missing values
        and optionally scaling the data.
        
        :param fill_strategy: The strategy for filling missing values.
        :param fill_value: The value to fill the missing values with when fill_strategy='constant'.
        :param scale_data: Flag indicating whether to scale the data.
        :return: The preprocessed DataFrame.
        """
        self.fill_missing_values(strategy=fill_strategy, fill_value=fill_value)
        if scale_data:
            self.auto_scale_data()
        return self.df
    
    def display_correlation_matrix(self, method='pearson', figsize=(10, 8), annot=True, cmap='coolwarm'):
        """
        Displays the correlation matrix for the numeric columns of the DataFrame.
        
        :param method: The method for calculating the correlation ('pearson', 'kendall', 'spearman').
        :param figsize: The size of the figure.
        :param annot: Flag indicating whether to annotate the correlation coefficients in the heatmap.
        :param cmap: The color map to use for the heatmap.
        """
        numeric_columns = self.df.select_dtypes(include=['float64', 'int64']).columns
        corr_matrix = self.df[numeric_columns].corr(method=method)
        
        # Create a mask for the upper triangle
        mask = np.triu(np.ones_like(corr_matrix, dtype=bool))
        
        # Set up the matplotlib figure
        fig, ax = plt.subplots(figsize=figsize)
        
        # Generate a custom diverging colormap
        cmap = sns.diverging_palette(220, 10, as_cmap=True)
        
        # Draw the heatmap with the mask and correct aspect ratio
        sns.heatmap(corr_matrix, mask=mask, cmap=cmap, vmax=.3, center=0,
                    square=True, linewidths=.5, cbar_kws={"shrink": .5}, annot=annot, fmt='.2f')
        
        plt.title(f'Correlation Matrix ({method.capitalize()} Correlation)')
        plt.show()
    
